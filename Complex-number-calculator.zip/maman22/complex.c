//This file contain multiple functions that handle all the commands, like inserting it to a variable, printing and other math handling.
#include "complex.h"

//This function gets a pointer to a complex number and 2 double numbers and assigns them to the complex number parameters
complex* read_comp(complex *var, double real, double imag)
{
	var->real = real;
	var->imag = imag;
	return var;
}

//This function gets a pointer to a complex number and prints it in the form of a + (b)i
void print_comp(complex *var)
{
	printf("%.2f + (%.2f)i\n",var->real,var->imag);
}

//This function gets 2 pointers to complex numbers, and returns a pointer to a complex number that represents the sum of them
complex *add_comp(complex *var1, complex *var2)
{
	complex *tmp;
	tmp->real = var1->real + var2->real;
	tmp->imag = var1->imag + var2->imag;
	return tmp;
}

//This function gets 2 pointers to complex numbers, and returns a pointer to a complex number that represents the difference of them
complex *sub_comp(complex *var1, complex *var2)
{
	complex *tmp;
	tmp->real = var1->real - var2->real;
	tmp->imag = var1->imag - var2->imag;
	return tmp;
}

//This function gets a pointer to a complex number and a double(real type) and returns a pointer to a complex number that represents the multiplication result of them 
complex *mult_comp_real(complex *var1, double var2)
{
	complex *tmp;
	tmp->real = var2 * var1->real;
	tmp->imag = var2 * var1->imag;
	return tmp;
}

//This function gets a pointer to a complex number and a double(imaginary type) and returns a pointer to a complex number that represents the multiplication result of them
complex *mult_comp_img(complex *var1, double var2)
{
	complex *tmp;
	tmp->real = (-1) * var2 * var1->imag;
	tmp->imag = var2 * var1->real;
	return tmp;
}

//This function gets 2 pointers to complex numbers, and returns a pointer to a complex number that represents the multiplication result of them
complex *mult_comp_comp(complex *var1, complex *var2)
{
	complex *tmp;
	tmp->real = var1->real * var2->real - var1->imag * var2->imag;
	tmp->imag = var1->real * var2->imag + var1->imag * var2->real;
	return tmp;
}

//This function gets a pointer to a complex number and returns a pointer to a complex number that represents the absolute value of it
double abs_comp(complex *var)
{
	return sqrt(var->real * var->real + var->imag * var->imag);
}
