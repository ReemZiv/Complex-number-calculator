//This file reads the input, analyzing it, finding errors in it, alerting them to the user and finally runs the mathcing function according to the input.
#include "complex.h"

complex A,B,C,D,E,F,N;
complex *comp_vars[] = {&A,&B,&C,&D,&E,&F,&N};
complex *tmp_pointer,*tmp_pointer2;
int tmp;

main()
{	
	printf("This is a complex numbers math calculator\n");
	while(1 > 0)
	{
		printf("\nPlease enter a command:");
		tmp = analyze_input(comp_vars);
		if(tmp == 0){ //Analyzing the input
			continue;
		}
		
		if(tmp == STOP) //Checking if stop was entered
			break;
			
		if(handle_global_error(comp_vars) == 0) { //Handling errors
			continue;	
		}
		
		if(run_func(comp_vars) == 1) //Running the function
			printf("Command completed :)\n"); 
	}
	printf("Stopping the program!\n");
} 
