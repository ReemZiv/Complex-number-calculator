//This file contains function to help myconp.c to read the input, analyze it, find errors in it, alert them to the user and finally to run the mathcing function according to the input.
#include "complex.h"

//declarations
complex *tmp_pointer,*tmp_pointer2;
int i,j,size = 1;
double real,imag;
char *command,*var1,*var2,*var3;
char *token, *tmp_token;
char *line;

//This function gets a string and returns a pointer to the complex number in it. If doesn't, it returns N_p which signals the function didn't find one 
complex* get_value(char* line, complex* comp_vars[])
{
	int i;
	for(i = 0; isspace(line[i]); i++) //Moving until it finds alphabetical character
		;
		
	if(line[i] >= 'A' && line[i] <= 'F')
			return comp_vars[line[i] - 'A'];
	return comp_vars[N_P_INDEX];
	
}

//This function gets a line and the command of the line and checks if there is Extra text that doesn't match the command syntax if so, returns 1 else, returns 0.
int check_extra(char* line)
{
	int i,is_point = 1, is_in = 1;//is_point represents if the method got to a decimal point, is_in represents if the method got to the digit part in the line.
	//The function goes through all spaces and the double in the string if there is and checks if the final character is the end of the string, if so it means that the string represents a double number;
	
	for(i = 0; isspace(*(line + i)); i++)
		;
		
	for(i; isdigit(*(line + i)) || (*(line + i) == '.' && is_point == 1) || (*(line + i) == '-' && is_in == 1); i++){
		if(*(line + i) == '.')
			is_point = 0;
		if(isdigit(*(line + i)))
			is_in = 0;
	}
	
	if(line[i] >= 'A' && line[i] <= 'F' && is_in == 1)
		i++;
		
	else if (is_in == 1){
		for(i; !isspace(*(line + i)) && *(line + i) != '\0'; i++)
			;
	}
	
	for(i; isspace(*(line + i)); i++)
		;
	
	if(*(line + i) == '\n' || *(line + i) == '\0')
		return 0;
	return 1;
}		

//This function gets a line and removes all the spaces and tabs from the line
void remove_spaces(char* line) {
    char* tmp = line;
    do {
        while (isspace(*tmp) && *tmp != '\n') {
            ++tmp;
        }
    } while (*line++ = *tmp++);
}

//This function gets a line and checks if it represents a double number and returns >0(length of the double) if so, else returns 0
int is_double(char* line)
{
	int i = 1, is_point = 1, is_in = 1;//is_point represents if the method got to a decimal point, is_in represents if the method got to the digit part in the line.
	//The function goes through all spaces and the double in the string if there is and checks if the final character is the end of the string, if so it means that the string represents a double number
	for(i = 0; isdigit(*(line + i)) || (*(line + i) == '.' && is_point == 1) || (*(line + i) == '-' && is_in == 1) || ((isspace(*(line + i)) || *(line + i) == '\t') && is_in == 1); i++){
		if(*(line + i) == '.')
			is_point = 0;
		if(isdigit(*(line + i)))
			is_in = 0;
	}
	remove_spaces(line);
	if(is_in == 0 && (*(line + i) == '\0' || *(line + i) == '\n'))
		return i;
	return 0;
}

//This functions checks if a line is empty and returns 1 if so, 0 if not
int is_blank(char* line) {
	char* tmp = strdup(line);
	remove_spaces(tmp);
	if(tmp[0] == '\0' || tmp[0] == '\n'){
		return 1;
	}
	return 0;
}

//This function checks if a space between the command and the complex number(which is a must part of the syntax) is missing, returns 1 if space is missing and 0 if isn't
int is_space_missing(char* line) {
	 int i;
	 for(i = 0; *(line + i) != '\0' && *(line + i) != '\n' && isupper(*(line + i)) == 0; i++)
	 	;
	 if(*(line + i) != '\0' && *(line + i) != '\n' && isupper(*(line + i)) > 0)
	 	return 1;
	 return 0;
}

//This function gets the line from the input, and analyzes it to parts(command,variables and rest of the line) and also check a few possible errors
int analyze_input(complex *comp_vars[])
{
	line = (char*) malloc(size);
	if (getline(&line,&size,stdin) == -1){ //Getting the line and checking if its EOF
		printf("\nReached EOF without stop command causing to stop the program!!!\n");
		exit(0);
	}
	printf("\n%s",line);
		
	if(strncmp(line, "stop",STOP_LEN) == 0){ //Checking if stop was entered and if it is syntax valid
		if(is_blank(line+STOP_LEN) == 1)
			return STOP;
		else{
			printf("Extraneous text after end of command\n");
			return 0;
		}
	}
		
	if(is_blank(line) == 1) //Checking if the line is blank 
		return 0;
	
	//Splitting the line to its parts: token - the first part until the comma(if there is, if isn't it gets the whle line)
	//								   command - the command of the line, what function to run
	//                                 line - the rest of the line that can contain variables, spaces, tabs and other syntax errors
	token = strtok_r(line,",",&line);
	command = strtok_r(token," ",&token);
	tmp_pointer = get_value(token,comp_vars); //getting the first parameter for the functions
	return 1;
}

//This function checks for errors that some of the functions may have or for syntax errors and returns 1 if no errors were found or 0 if errors were found
int handle_global_error(complex *comp_vars[])
{
	if(is_blank(token) == 1){ 
		if(is_space_missing(command) == 1) //Checking for a missing space between the command and the rest
			printf("Missing space\n");
		else{ //Checking for a missing parameter or illegal comma or multiple consecutive commas
			if(is_blank(line) == 1) 
				printf("Missing parameter\n");
			else {
				if(line[0] == ',')
					printf("Multiple consecutive commas\n");
				else
					printf("Illegal comma\n"); 
			}
		}
		return 0;
	}
	
	for(i = 0; isspace(*(line + i)); i++)
		;
	for(j = 0; isspace(*(token + j)); j++)
		;
		
	if(line[0] == ','){ //Checking for multiple consecutive commas
		printf("Multiple consecutive commas\n");
		return 0;
	}
		
	if(tmp_pointer == comp_vars[N_P_INDEX]){ //Checking if a complex number that isn't between A-G was inputted
		printf("Undefined complex number\n");
		return 0;
	}
		
	tmp_token = strdup(token);
	remove_spaces(tmp_token);
	if((tmp_token[1] >= '!' && tmp_token[1] <= '/' && tmp_token[1] != ',') || (tmp_token[1] >= ':' && tmp_token[1] <= '@')){//Checking if other seperator like ':','.' 					   																											that isn't syntax valid was inserted
		if(strcmp(command,"print_comp") != 0 && strcmp(command,"abs_comp") != 0){ //print_comp and abs_comp don't have commas
			printf("Expected comma but other seperator was inputted\n");
			return 0;
		}
	}
	 
	if(line[i] == '\0' && strcmp(command,"print_comp") != 0 && strcmp(command,"abs_comp") != 0){ //Checking for a missing comma between the line parts
		if(is_blank(line) == 1 && check_extra(token) == 1){ //If token contains more than one parameter, it means a comma is missing
			printf("Missing comma\n");
			return 0;
		}
		printf("Missing parameter\n");
		return 0;
	}
		
	if(((strcmp(command,"abs_comp") == 0 || strcmp(command,"print_comp") == 0) && check_extra(token) == 1) || (strcmp(command,"read_comp") != 0 && check_extra(line) == 1)){
		printf("Extraneous text after end of command\n");
		return 0;
	}
	
	remove_spaces(line);
	remove_spaces(token);
	return 1;
}

//This function runs a function according to the input and returns 1 if it was successful or 0 if it failed
int run_func(complex *comp_vars[])
{
	if(strcmp(command,"read_comp") == 0){
		var1 = strtok_r(line,",",&line); //read_comp is the only command that has 3 parameters so we will split it again to another variable
		
		//Checking again a few errors that we couldn't find earlier because this command has 3 parameters
		if(line[0] == ','){
			printf("Multiple consecutive commas\n");
			return 0;
		}

		if(check_extra(token) == 1 || check_extra(var1) == 1){ //If there is a missing comma, token and var 1 will have extra parameter
			printf("Missing comma\n");
			return 0;
		}
		
		if(var1[0] == '\0' || line[0] == '\0'){ //If var1 or line don't contain parameters, it means that a parameter is missing
			
			printf("Missing parameter\n");
			return 0;
		}
		
			
		if(check_extra(line) == 1){ 
			printf("Extraneous text after end of command\n");
			return 0;
		}
		
		if(is_double(line) == 0 || is_double(var1) == 0){ //read_comp have 2 parameters that are doubles
			printf("Invalid parameter - not a number\n");
			return 0;
		}
		
		real = atof(var1); //converting to double number
		imag = atof(line); //converting to double number
		tmp_pointer = read_comp(tmp_pointer,real,imag); //running read_comp
	}
		
	else if(strcmp(command,"print_comp") == 0){
		if(is_blank(line) == 0 || check_extra(token + 1) == 1){
			printf("Extraneous text after end of command\n");
			return 0;
		}
		
		print_comp(tmp_pointer);
	}
		
	else if(strcmp(command,"add_comp") == 0){
		tmp_pointer2 = get_value(line,comp_vars); //getting second parameter
		if(tmp_pointer2 == comp_vars[N_P_INDEX]){ //Checking second parameter validity
			printf("Undefined complex parameter\n");
			return 0;
		}
		fflush(stdout); //Some of the outputs won't be printed without this line because it is in the buffer.
		print_comp(add_comp(tmp_pointer,tmp_pointer2)); //running add_comp
	}
		
	else if(strcmp(command,"sub_comp") == 0){
		tmp_pointer2 = get_value(line,comp_vars); //getting second parameter
		if(tmp_pointer2 == comp_vars[N_P_INDEX]){//checking second parameter validity
			printf("Undefined complex parameter\n");
			return 0;
		}
		fflush(stdout); //Some of the outputs won't be printed without this line because it is in the buffer.
		print_comp(sub_comp(tmp_pointer,tmp_pointer2)); //running sub_comp
	}
		
	else if(strcmp(command,"mult_comp_comp") == 0){ 
		tmp_pointer2 = get_value(line,comp_vars); //getting second parameter
		if(tmp_pointer2 == comp_vars[N_P_INDEX]){ //checking second parameter validity
			printf("Undefined complex parameter\n");
			return 0;
		}
		fflush(stdout); //Some of the outputs won't be printed without this line because it is in the buffer.
		print_comp(mult_comp_comp(tmp_pointer,tmp_pointer2)); //running mult_comp_comp
	}
		
	else if(strcmp(command,"mult_comp_real") == 0){
		if (is_double(line) == 0){ //checking second parameter validity
			printf("Invalid parameter – not a number\n");
			return 0;
		}
		
		fflush(stdout); //Some of the outputs won't be printed without this line because it is in the buffer.
		real = atof(line); //getting second parameter
		print_comp(mult_comp_real(tmp_pointer,real)); //running mult_comp_real
	}
		
	else if(strcmp(command,"mult_comp_img") == 0){
		if (is_double(line) == 0){ //checking second parameter validity
			printf("Invalid parameter - not a number\n");
			return 0;
		}
		
		fflush(stdout); //Some of the outputs won't be printed without this line because it is in the buffer.
		imag = atof(line); //getting second parameter
		print_comp(mult_comp_img(tmp_pointer,imag)); //running mult_comp_img
	}
		
	else if(strcmp(command,"abs_comp") == 0){ 
		if(is_blank(line) == 0 || check_extra(token + 1) == 1){
			printf("Extraneous text after end of command\n");
			return 0;
		}
		printf("%.2f\n",abs_comp(tmp_pointer));
	}
		
	else{ //If the command didn't match anyone, it means a wrong command was inputted
		printf("Undefined command name\n");
		return 0;
	}
	
	return 1; //If a function was ran succesfully, it returns 1 to signal it
}	
