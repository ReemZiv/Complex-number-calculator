#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
#include <ctype.h>

#define STOP -1
#define STOP_LEN 4
#define N_P_INDEX 7
typedef struct complex
{
	double real;
	double imag;
} complex;

//complex.c functions
complex* read_comp(complex *var, double real, double imag);
void print_comp(complex *);
complex* add_comp(complex *, complex *);
complex* sub_comp(complex *, complex *);
complex* mult_comp_real(complex *, double);
complex* mult_comp_img(complex *, double);
complex* mult_comp_comp(complex *, complex *);
double abs_comp(complex *);

//input_handle.c functions
complex* get_value(char* , complex* []);
int check_extra(char*);
void remove_spaces(char* );
int is_blank(char*);
int is_double(char*);
int is_space_missing(char*);
int analyze_input(complex* []);
int handle_global_error(complex *[]);
int run_func(complex* []);
